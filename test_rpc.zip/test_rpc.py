


import ray
from ray import serve
from ray.serve.drivers import gRPCDriver



@serve.deployment
class D1:
    def __call__(self, input):
        return input["a"]



deployment_graph = gRPCDriver.bind(D1.bind())

# internal schema
#serve.run(GrpcDriver.bind(D1.bind()))


# customer schema
# serve.run(MyIngress.bind(D2.bind()))

#time.sleep(36000)
