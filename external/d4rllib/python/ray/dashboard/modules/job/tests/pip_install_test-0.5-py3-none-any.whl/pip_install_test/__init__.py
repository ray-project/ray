print("Good job!  You installed a pip module.\n\nNow get back to work!")
